from stepfunctions.steps import *
import utils
import constants

def fetch_config_from_db(config_id, type):
    return utils.fetch_config_from_db(config_id, type)

class LambdaStepBuilder:


    def getStep(self, context, module_id,definition, config_file_location,workflow_version_id,workflow_module_id):
        #print(definition)
        extra = {}
        config_yaml = fetch_config_from_db(workflow_version_id, constants.WORKFLOW_CONFIG_VERSION)
        modules = config_yaml.get('modules')
        for module in modules:
            if modules[module].get('id') == workflow_module_id:
                name = module
                break
        steps = config_yaml.get('steps')    
        extra['saveOutput'] = steps[name].get('saveOutput')
        extra['skipModule'] = steps[name].get('skipModule')
        metadata = definition.get('metaData')
        state_id = metadata['description']
        print("LambdaLoader", state_id)
        artifact_location = utils.get_artifact_location(module_id)
        print("artifact_location",artifact_location)
        function_name = utils.resolvePlaceHolderValues(metadata['description'], context)
        inputs = definition['input']['source']
        functions = definition['functional']['process']
        
        outputs_dest = definition['output']['dest']
        params = {"input": {"source": inputs}, "functional": {"process":functions}, "output": {"dest": outputs_dest},"extra":extra,"config_file_location":config_file_location,"artifact_location":artifact_location}
        step = LambdaStep(
            state_id=state_id,
            parameters={
                "FunctionName.$": function_name,
                "Payload": params
            }, result_path="$.results." + metadata['name']
        )
        return step



