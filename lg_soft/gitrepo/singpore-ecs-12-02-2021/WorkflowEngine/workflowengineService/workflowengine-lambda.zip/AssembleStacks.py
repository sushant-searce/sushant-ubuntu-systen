from datetime import datetime
import yaml
from troposphere.awslambda import Function, Code
from troposphere.ecs import TaskDefinition
from troposphere.iam import Policy, Role
from troposphere import Parameter, Ref, Template, GetAtt, Join, Output
from troposphere.sagemaker import Model, ContainerDefinition
from sagemaker.amazon.amazon_estimator import get_image_uri
from troposphere import Parameter, Ref, Template, Tags, If, Equals, Not, Join, Output
from troposphere.awslambda import Version
from troposphere.constants import C1_MEDIUM, KEY_PAIR_NAME, M1_LARGE, M1_MEDIUM, SUBNET_ID, M4_LARGE, NUMBER
import troposphere.emr as emr 
from troposphere.emr import Application, Step
import troposphere.iam as iam
from troposphere import ( AWS_ACCOUNT_ID, Parameter, Ref, Template, Tags, If, Equals, Not, Join, Output)
from troposphere import glue
from troposphere.iam import ManagedPolicy, Policy, Role
from troposphere.glue import ( CatalogTarget, Crawler, Database, DatabaseInput, Job, JobCommand, S3Target, Schedule, SchemaChangePolicy, Targets)
from constants import SAGEMAKER_EXECUTION_ARN

sagemaker_execution_arn = SAGEMAKER_EXECUTION_ARN

def build_lambda_stack(definition, t):
    # TODO: Need to build the execution policy in a fine grained manner.
    #  Right now, we are adding a role to the lambda that gives the lambda big permission
    t.add_resource(Role(
        "LambdaExecutionRole",
        Path="/",
        Policies=[Policy(
            PolicyName="root",
            PolicyDocument={
                "Version": "2012-10-17",
                "Statement": [{
                    "Action": ["logs:*"],
                    "Resource": "arn:aws:logs:*:*:*",
                    "Effect": "Allow"
                }, {
                    "Action": "*",
                    "Resource": "*",
                    "Effect": "Allow"
                }]
            })],
        AssumeRolePolicyDocument={"Version": "2012-10-17", "Statement": [
            {
                "Action": ["sts:AssumeRole"],
                "Effect": "Allow",
                "Principal": {
                    "Service": [
                        "lambda.amazonaws.com"
                    ]
                }
            }
        ]},
    ))
    # s3Key = definition.get("config").get("artifactName") or definition.get("config").get("ArtifactName")
    import constants

    function = t.add_resource(Function(
        definition.get("config").get("config").get("name"),
        Code=Code(
            S3Bucket=definition.get("config").get("config").get("ArtifactLocation"),
            S3Key=definition.get("config").get("config").get("ArtifactName")
        ),
        Handler=definition.get("config").get("config").get("handler"),
        FunctionName=Join('', ['lambda-', definition.get("config").get("config").get("name"), "-", Ref('RunId')]),
        Role=GetAtt("LambdaExecutionRole", "Arn"),
        Runtime=definition.get("config").get("config").get("runTime"),
        MemorySize=definition.get("config").get("config").get("MemorySize"),
        Layers=[definition.get("config").get("config").get("layers")]
        #print(Layers)

    ))
    #print(Output(definition.get("config").get("config").get("name"), Description="Output from Lambda Step", Value=Ref(function), ))
    return Output(definition.get("config").get("config").get("name"), Description="Output from Lambda Step", Value=Ref(function), )

def build_model_stack(definition, t):
    #model_name = definition.get("name") + datetime.now().strftime("%Y%m%d%H%M%S")
    container_definition = ContainerDefinition(
        ModelDataUrl=definition.get("config").get("ArtifactLocation"),
        Image=get_image_uri('ap-south-1', definition.get("config").get("image")
                            , repo_version='latest'))
    model = t.add_resource(Model("SagemakerModel",
                                 ExecutionRoleArn=sagemaker_execution_arn,
                                 ModelName=Join('',
                                                ['model-', definition.get("name"), "-", Ref('RunId')]),
                                 Containers=[container_definition]))
    return Output(definition.get("name"), Description="Output From Model Step",
                  Value=GetAtt(model, "ModelName"))

def build_ecs_task(definition, t):
    task_name = definition.get("config").get("Name")
    cpu = definition.get("config").get("Cpu")
    memory = definition.get("config").get("Memory")
    image_name = definition.get("config").get("Image")
    task_definition = t.add_resource(TaskDefinition(
        task_name,
        RequiresCompatibilities=['FARGATE'],
        Cpu=cpu,
        Memory=memory,
        NetworkMode='awsvpc',
        ContainerDefinitions=[
            ContainerDefinition(
                Name='container1',
                Image='925881846319.dkr.ecr.ap-south-1.amazonaws.com/lpp/dockers:lpp_wrapper_mumbai',
                Essential=False,
                PortMappings = [
                    PortMapping(
                        ContainerPort=80,
                        HostPort=80,
                        Protocol='tcp'
                    )
                ],
                EntryPoint=[
                    "/tmp/home/start.sh"
                ],
                MountPoints=[
                    MountPoint(
                        SourceVolume='lpp',
                        ContainerPath='/tmp/home'
                    )
                ],
                LogConfiguration=[
                    LogConfiguration(
                        LogDriver='awslogs',
                        Options={
                            "awslogs-group": "/ecs/ecsTask",
                            "awslogs-region": "ap-south-1",
                            "awslogs-stream-prefix": "ecs"
                        }
                    )
                ]
            ),
            ContainerDefinition(
                Name='container2',
                Image=image_name,
                Essential=False,
                PortMappings = [
                    PortMapping(
                        ContainerPort=81,
                        HostPort=81,
                        Protocol='tcp'
                    )
                ],
                EntryPoint=[
                    "python"
                ],
                Command=[
                    "yaml_parser.py",
                    "--yaml",
                    "tempconfig.yaml"
                ],
                MountPoints=[
                    MountPoint(
                        SourceVolume='lpp',
                        ContainerPath='/tmp/home'
                    )
                ],
                DependsOn=[
                    ContainerDependency(
                        Condition="COMPLETE",
                        ContainerName="container1"
                    )
                ],
                LogConfiguration=[
                    LogConfiguration(
                        LogDriver='awslogs',
                        Options={
                            "awslogs-group": "/ecs/ecsTask",
                            "awslogs-region": "ap-south-1",
                            "awslogs-stream-prefix": "ecs"
                        }
                    )
                ]
            ),
            ContainerDefinition(
                Name='container3',
                Image='925881846319.dkr.ecr.ap-south-1.amazonaws.com/lpp/dockers:lpp_wrapper_mumbai',
                Essential=True,
                PortMappings = [
                    PortMapping(
                        ContainerPort=82,
                        HostPort=82,
                        Protocol='tcp'
                    )
                ],
                EntryPoint=[
                    "/tmp/home/end.sh"
                ],
                MountPoints=[
                    MountPoint(
                        SourceVolume='lpp',
                        ContainerPath='/tmp/home'
                    )
                ],
                DependsOn=[
                    ContainerDependency(
                        Condition="COMPLETE",
                        ContainerName="container2"
                    )
                ],
                LogConfiguration=[
                    LogConfiguration(
                        LogDriver='awslogs',
                        Options={
                            "awslogs-group": "/ecs/ecsTask",
                            "awslogs-region": "ap-south-1",
                            "awslogs-stream-prefix": "ecs"
                        }
                    )
                ]
            )
        ]
    ))
    t.add_resource(task_definition)
    return Output(task_name, Description="Output From ECS Create Task Step",
                  Value=Ref(task_definition))

def build_emr_stack(definition, t):
    
    emr_service_role = t.add_resource(iam.Role(
        'EMRServiceRole',
        RoleName= 'lg-dev-emrServiceRole-v1',
        AssumeRolePolicyDocument={
            "Version": "2008-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {
                    "Service": [
                        "elasticmapreduce.amazonaws.com"
                    ]
                },
                "Action": ["sts:AssumeRole"]
            }]
        },               
        ManagedPolicyArns=[
            'arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceRole',
            'arn:aws:iam::aws:policy/AmazonS3FullAccess'
        ]
    ))
    # EMR EC2 Role
    emr_job_flow_role = t.add_resource(iam.Role(
        "EMRJobFlowRole",
        RoleName= 'lg-dev-emrEc2Role-v1',
        AssumeRolePolicyDocument={
            "Version": "2008-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {
                    "Service": [
                        "ec2.amazonaws.com"
                    ]
                },
                "Action": ["sts:AssumeRole"]
            }]
        },
        ManagedPolicyArns=[
            'arn:aws:iam::aws:policy/service-role/AmazonElasticMapReduceforEC2Role',
            'arn:aws:iam::aws:policy/AmazonS3FullAccess'
        ]
    ))
    emr_instance_profile = t.add_resource(iam.InstanceProfile(
        "EMRInstanceProfile",
        Roles=[Ref(emr_job_flow_role)]
    ))
    clusterName = definition.get("config").get("config").get("clusterName") 
    releaseLabel = definition.get("config").get("config").get("releaseLabel")
    logUri = definition.get("config").get("config").get("logUri")
    ec2KeyPair = 'searce-ap-southeast-1-kp' #definition.get("config").get("config").get("ec2KeyPair")
    ec2SubnetId = 'subnet-015d723fbc480ee95' #definition.get("config").get("config").get("ec2SubnetId")
    #Master instance details
    masterInstanceName = definition.get("config").get("config").get("masterInstanceName")
    masterInstanceCount = definition.get("config").get("config").get("masterInstanceCount")
    masterInstanceType = definition.get("config").get("config").get("masterInstanceType")
    masterInstanceMarket = definition.get("config").get("config").get("masterInstanceMarket")
    #Core instance details
    coreInstanceName = definition.get("config").get("config").get("coreInstanceName")
    coreInstanceCount = definition.get("config").get("config").get("coreInstanceCount")
    coreInstanceType = definition.get("config").get("config").get("coreInstanceType")
    coreInstanceMarket = definition.get("config").get("config").get("coreInstanceMarket")
    # Application Type (Spark ,Hadoop, Hive, Mahout, Pig)
    applicationName = definition.get("config").get("config").get("applicationName")
    cluster = t.add_resource(emr.Cluster(
        'EMRCluster',
        Name=clusterName,
        ReleaseLabel=releaseLabel,
        LogUri=logUri,
        JobFlowRole=Ref(emr_instance_profile),
        ServiceRole=Ref(emr_service_role),
        VisibleToAllUsers=True,
        Instances=emr.JobFlowInstancesConfig(
            Ec2KeyName=ec2KeyPair,
            Ec2SubnetId=ec2SubnetId, 
            MasterInstanceGroup=emr.InstanceGroupConfigProperty(
                Name=masterInstanceName,
                InstanceCount=masterInstanceCount,
                InstanceType=masterInstanceType,
                Market=masterInstanceMarket # EC2 Market : 'SPOT' or 'ON_DEMAND'
            ),
            CoreInstanceGroup=emr.InstanceGroupConfigProperty(
                Name=coreInstanceName,
                Market=coreInstanceMarket,  # EC2 Market :- 'SPOT' or 'ON_DEMAND'
                InstanceCount=coreInstanceCount,
                InstanceType=coreInstanceType,
            )
        ),
        Applications=[
            emr.Application(Name=applicationName)
        ],
    ))
    
    return Output(clusterName, Value=Ref(cluster), Description='Output of EMR Cluster')


def build_glue_stack(definition, t):
    ########################
    ## #Creating IAM Role ##
    ########################
    lg_dev_glueServiceRole=t.add_resource(Role(
        "GlueServiceRole",
        RoleName= 'lg-dev-glueServiceRole-v1',
        AssumeRolePolicyDocument={
            "Version": "2008-10-17",
            "Statement": [{
                "Effect": "Allow",
                "Principal": {
                    "Service": [
                        "glue.amazonaws.com"
                    ]
                },
                "Action": ["sts:AssumeRole"]
            }]
        },
        ManagedPolicyArns=[
            'arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole',
            'arn:aws:iam::aws:policy/AmazonS3FullAccess'
        ]
    ))
    ##########################################
    ## Dynamically fetching required values ##
    ##########################################
    dbName = definition.get("config").get("config").get("dbName") #+ datetime.now().strftime("%Y%m%d%H%M%S")
    crawlerName = 'searcegluetestcrawler' 
    #definition.get("config").get("config").get("crawlerName") #+ datetime.now().strftime("%Y%m%d%H%M%S")
    dataTarget = definition.get("config").get("config").get("dataTarget")
    jobName = definition.get("config").get("config").get("jobName") #+ datetime.now().strftime("%Y%m%d%H%M%S")
    jobVersion = str(definition.get("config").get("config").get("jobVersion"))
    jobMaxCapacity = definition.get("config").get("config").get("jobMaxCapacity")
    jobTimeout = definition.get("config").get("config").get("jobTimeout")
    jobScriptLocation = definition.get("config").get("config").get("jobScriptLocation")
    jobExecuteType = definition.get("config").get("config").get("jobExecuteType")

    ############################
    ## Creating Glue Database ##
    ############################
    database=t.add_resource(Database(
        'crateDatabase',
        CatalogId=Ref(AWS_ACCOUNT_ID),
        DatabaseInput=(DatabaseInput(
            Name=dbName,
            Description='Stores the tables created by crawler'
        ))
    ))
    ######################
    ## Creating Crawler ##
    ######################
    crawler = t.add_resource(Crawler(
        'createCrawler',
        Name=crawlerName,
        DatabaseName=Ref(database),
        Role=Ref(lg_dev_glueServiceRole),
        Tags = {
            "Name" : "lg-dev"
        },

        Targets=(Targets(
            S3Targets=[S3Target(
                 Path=dataTarget
            )]
        ))
    ))

    x = [
        Output(
            dbName,
            Value=Ref(database),
            Description='Output of database in glue data catelog'
        ),
        Output(
            crawlerName,
            Value=Ref(crawler),
            Description='Output of crawler'
        ),
    ]

    for i in x:
        return i

def build_cft_definition(config_yaml):
    t = Template()
    t.set_version("2010-09-09")
    outputs = []
    t.add_parameter(Parameter("RunId",Type="String"))
    deployments = config_yaml['deployments']
    for deployment in deployments:
        deployment_type = deployment.get('type')
        if deployment_type == "function":
            outputs.append(build_lambda_stack(deployment, t))
        elif deployment_type == "model":
            outputs.append(build_model_stack(deployment, t))
        elif deployment_type == "emr":
            outputs.append(build_emr_stack(deployment, t))
        #elif deployment_type == "glue":
        #    outputs.append(build_glue_stack(deployment, t))
        elif deployment_type == "fargate":
            pass
        elif deployment_type == "EC2":
            pass
            #outputs.append(build_ecs_task(deployment, t))

    t.add_output(outputs)
    return t #t.to_yaml()