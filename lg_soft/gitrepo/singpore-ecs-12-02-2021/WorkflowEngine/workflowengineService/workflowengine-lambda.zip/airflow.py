import uuid
import base64
import os
#from AirflowModules.lambdatest import Load_CSV_Data_From_S3

def dag(workflow_execution_id):
    
    definition = """import flask
import yaml
import json
import boto3
import uuid
import base64
import time
from airflow import DAG
from flask import request
from airflow.models import DagRun
from airflow.utils.dates import days_ago
from datetime import datetime, timedelta
from airflow.operators.python_operator import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.contrib.hooks.aws_hook import AwsHook
from airflow.contrib.hooks.aws_lambda_hook import AwsLambdaHook
from airflow.providers.amazon.aws.hooks.lambda_function import AwsLambdaHook
from modules.LambdaOperatorBuilder import LambdaOperatorBuilder
from modules.ECSOperatorBuilder import ECSOperatorBuilder
from modules.NotificationOperatorBuilder import NotificationOperatorBuilder
from modules.GlueOperatorBuilder import GlueOperatorBuilder
from modules.EmrOperatorBuilder import EmrOperatorBuilder
from modules.SageMakerOperatorBuilder import SageMakerOperatorBuilder



def read_deployment_yaml():
    file_name= "searceLG/definition.yaml"
    bucket = 'workflow-engine-data-sg'
    s3_client = boto3.client('s3')
    response = s3_client.get_object(Bucket=bucket, Key=file_name)
    deployment = yaml.safe_load(response["Body"])
    return deployment

updated_definition = json.loads(read_deployment_yaml())

def createDynamicETL(task_id, callableFunction):
    task = PythonOperator(
        task_id = task_id,
        provide_context=True,
        python_callable = eval(callableFunction),
        dag = dag,

    )
    return task

start = updated_definition.get('StartAt')
states = updated_definition.get('States')

def Creating_Resources(ds, **kwargs):

    encoded = states.get('Creating Resources').get('Parameters').get('Payload').get('cft_template')
    Function_name = states.get('Creating Resources').get('Parameters').get('FunctionName')
    stack_name = 'cft-' + str(uuid.uuid4())[:8]
    hook = AwsLambdaHook(Function_name,
                    region_name='ap-south-1',
                    log_type='None',
                    qualifier='$LATEST',
                    invocation_type='RequestResponse',
                    config=None,
                    aws_conn_id='aws_default')
    payload= '{"stackName": "%s", "cft_template": "%s" }' %(stack_name,encoded)
    response_1 = hook.invoke_lambda(payload=payload)
    print ('Response--->' , response_1)
    kwargs['ti'].xcom_push(key='create_resources', value = stack_name )
    return stack_name

def Wait_for_Resources_to_be_Created(**kwargs):
    time.sleep(30)
    return "Wait Completed"

def Get_Resource_Creation_Status(ds,**kwargs):
    stack_id = kwargs['ti'].xcom_pull(task_ids='Creating_Resources')
    Function_name = updated_definition.get('States').get('Get Resource Creation Status').get('Parameters').get('FunctionName')
    hook = AwsLambdaHook(Function_name,
                    region_name='ap-south-1',
                    qualifier='$LATEST',
                    invocation_type='RequestResponse',
                    aws_conn_id='aws_default')
    payload= '{"stackName": "%s"}' %(stack_id)
    response_2 = hook.invoke_lambda(payload=payload)

def Deleting_Resources(ds,**kwargs):
    stack_name = kwargs['ti'].xcom_pull(task_ids='Creating_Resources')
    Function_name = states.get('Deleting Resources').get('Parameters').get('FunctionName')
    hook = AwsLambdaHook(Function_name,
                        region_name='ap-south-1',
                        qualifier='$LATEST',
                        invocation_type='RequestResponse',
                        aws_conn_id='aws_default')
    payload= '{"stackName": "%s"}' %(stack_name)
    response_2 = hook.invoke_lambda(payload=payload)

args = {
    'owner': 'airflow',
    'provide_context': True
}

dag = DAG('dynamic-searceLG', 
        description='fargate example',
        schedule_interval=None,
        start_date=datetime(2020, 12, 10),
        catchup=False)

start_worflow = DummyOperator(task_id='start', retries = 3, dag=dag)
end = DummyOperator(task_id='end', retries = 3, dag=dag)

lastDynamicTask = None

for i in states:
    task_id = i.replace(' ', '_')
    state = states.get(i)
    resource_type = states.get(i).get('Resource')
    task_type = states.get(i).get('Type')
    if task_type=="Task":
        if resource_type=='arn:aws:states:::lambda:invoke':
            if task_id=='Creating_Resources':
                dynamicTask = createDynamicETL('{}'.format(task_id), '{}'.format(task_id))
            elif task_id=='Get_Resource_Creation_Status':
                dynamicTask = createDynamicETL('{}'.format(task_id), '{}'.format(task_id))
            elif task_id=='Deleting_Resources':
                dynamicTask = createDynamicETL('{}'.format(task_id), '{}'.format(task_id))
            else:
                dynamicTask = LambdaOperatorBuilder().getOperator(dag, task_id, states)

        #elif resource_type=='arn:aws:states:::sns:publish':
        #    dynamicTask = NotificationOperatorBuilder().getOperator(dag, task_id, states)
        
        elif resource_type=='arn:aws:states:::ecs:runTask.sync':
            dynamicTask = ECSOperatorBuilder().getOperator(dag, task_id, states)

    else:
        dynamicTask = createDynamicETL('{}'.format(task_id), '{}'.format(task_id))

    if (lastDynamicTask == None):
        start_worflow.set_downstream(dynamicTask)
    else:
        lastDynamicTask.set_downstream(dynamicTask)

    lastDynamicTask = dynamicTask


lastDynamicTask.set_downstream(end)



#     dynamicTask = createDynamicETL('{}'.format(a), '{}'.format(a))
#     if (lastDynamicTask == None):
#         start_worflow.set_downstream(dynamicTask)
#         # lastDynamicTask = dynamicTask
#     else:
#         lastDynamicTask.set_downstream(dynamicTask)
    
#     lastDynamicTask = dynamicTask
# lastDynamicTask.set_downstream(end)""".replace('searceLG', str(workflow_execution_id))

    file_name = "dags/file_"+str(workflow_execution_id)+".py"
    open(file_name, "w").write(definition)

    print("please check the DAG ID : lg-soft-%d" % workflow_execution_id)

    os.system("scp -i searce-ap-northeast-2-kp.pem {} ubuntu@ec2-52-78-170-199.ap-northeast-2.compute.amazonaws.com:/root/airflow/dags".format(file_name))
