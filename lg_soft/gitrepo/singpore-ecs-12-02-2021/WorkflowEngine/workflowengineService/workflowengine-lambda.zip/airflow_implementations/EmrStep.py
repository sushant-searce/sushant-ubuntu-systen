from stepfunctions.steps import *
import utils


class EmrStepBuilder:

    def getStep(self, context, definition):
        metadata = definition.get('MetaData')
        state_id = metadata['description']
        print("Emr", state_id)
        stepName = 'lgDevEmrSparkStep'
        stepJarLocation = 's3://awsgluedemo123/code/wordcount-1.0.0.jar' 
        mainClass = 'com.example.spark.JavaWordCount'

        params = {"stepJarLocation": stepJarLocation, "mainClass": mainClass}
        # parameters = utils.resolvePlaceHoldersDict(definition['inputs'], context)
        step = EmrAddStepStep(
            state_id=state_id,
            parameters={
                "stepName.$": stepName,
                "Payload": params
            }, result_path="$.results." + metadata['name']
        )
        return step

