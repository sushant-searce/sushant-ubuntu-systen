from stepfunctions.steps import *
import utils


class GlueStepBuilder:

    def getStep(self, context, definition):
        metadata = definition.get('MetaData')
        state_id = metadata['description']
        print("Glue", state_id)
        jobName ='' 
        jobScriptLocation = '' 
        jobExecuteType = ''
        params = {"jobScriptLocation": jobScriptLocation, "jobExecuteType": jobExecuteType}
        # parameters = utils.resolvePlaceHoldersDict(definition['inputs'], context)
        step = GlueStartJobRunStep(
            state_id=state_id,
            parameters={
                "jobName.$": jobName,
                "Payload": params
            }, result_path="$.results." + metadata['name']
        )
        return step