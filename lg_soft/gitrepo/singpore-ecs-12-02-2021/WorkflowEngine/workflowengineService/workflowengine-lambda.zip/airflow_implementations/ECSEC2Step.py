import json

from stepfunctions.steps import EcsRunTaskStep

import utils
import constants

class ECSEC2StepBuilder:
    def getStep(self, context, module_id, definition, config_file_location):
        container_uri = utils.get_container_uri(module_id)
        task_arn = utils.update_ecs_task(container_uri)

        metadata = definition.get('metaData')
        state_id = metadata['description']
        print("Submitting ECS Task:", state_id)
        # step_name = metadata['resource']
        #parameters = definition['input']['source'], context

        input_file      = utils.resolvePlaceHolderValues(definition.get('input').get('source')[0].get("name"),context)
        input_location  = utils.resolvePlaceHolderValues(definition.get('input').get('source')[0].get('filePath'),context) #+ "/" + parameters[0][0].get("FileName")
        output_file     = utils.resolvePlaceHolderValues(definition.get("output").get('dest')[0].get('name'),context)
        output_location = utils.resolvePlaceHolderValues(definition.get("output").get('dest')[0].get('filePath'),context) #+ "/" + definition.get("outputs").get('dest').get('FileName')
        #codeLocation    = utils.resolvePlaceHolderValues(definition['deployment']['ArtifactLocation'],context)#+ "/" +definition['deployment']['name']
        codeLocation    = utils.get_artifact_location(module_id)
        # handler = definition['deployment']['handler']

        step = EcsRunTaskStep(
            state_id=state_id,
            parameters={
                # "capacityProviderStrategy": [
                #     {
                #         "capacityProvider": "BigDataCluster-CapacityProvider",
                #         "base": 0,
                #         "weight": 1
                #     }
                # ],
                "Cluster": "BigDataCluster", #This is to generated dynamically
                "TaskDefinition": task_arn,
                "NetworkConfiguration": {
                    "AwsvpcConfiguration": {
                        "AssignPublicIp": "DISABLED",
                        "SecurityGroups": [
                            'sg-050da7d38ee2884dc' #This is to generated dynamically
                        ],
                        "Subnets": [
                            'subnet-0f3429750577fffdf', 'subnet-005a86e513325c576' #This is to generated dynamically
                        ]
                    }
                },
                "PlacementConstraints": [
                    {
                        "Type": "distinctInstance"
                    }
                ],
                "Overrides": {
                    "ContainerOverrides": [
                        {
                            "Name": 'container1',
                            "Environment": [
                                {
                                    "Name": 'MODULE_LOC',
                                    "Value": codeLocation
                                },
                                {
                                    "Name": 'INPUT_LOC',
                                    "Value": input_location
                                },
                                {
                                    "Name": 'INPUT_FILE',
                                    "Value": input_file
                                },
                                {
                                    "Name": 'CONFIG_FILE',
                                    "Value": config_file_location
                                }
                            ]
                        },
                        {
                            "Name": 'container3',
                            "Environment": [
                                {
                                    "Name": 'OUTPUT_FILE',
                                    "Value": output_file
                                },
                                {
                                    "Name": 'OUTPUT_LOC',
                                    "Value": output_location
                                }
                            ]
                        }
                    ]
                }
            }

        )
        return step
