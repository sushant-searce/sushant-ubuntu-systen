import yaml
from flask import request
from stepfunctions.steps import Chain, FrozenGraph
from stepfunctions.workflow import Workflow, Execution
import boto3
import utils
import constants
from DeployStackHelper import create_deployment_steps
from InitScript import init
from StepFactory import StepFactory
from AirflowFactory import AirflowFactory
from sagemaker import Session
import uuid
import flask
import pdb
import os
import json
from airflow import dag
​
config_path = './config/'
BUCKET_NAME='workflow-engine-data-sg'
app = flask.Flask(__name__, static_url_path='')
​
"""
Given an id, fetches the config yaml from the DDB.
"""
@app.route('/static/require.js', methods=['GET'], endpoint="require_workflow")
​
def root():
    return app.send_static_file('require.js')
​
​
def fetch_config_from_db(config_id, type):
    return utils.fetch_config_from_db(config_id, type)
​
def fetch_module_config_from_db(module_id, workflow_version_id):
    return utils.fetch_module_config_from_db(module_id, workflow_version_id)
​
​
def fetch_deployment_config(workflow_version_id):
    return utils.fetch_deployment_config(workflow_version_id)
    # with open('./config-new/deployment.yaml') as file:
    #     return yaml.full_load(file)
​
​
def build_step(workflow_version_id, definition, context):
​
    module_id = definition.get("id")
    # config_loc =  definition.get("ConfigLocation")
    if definition.get("id") is not None:
        response = fetch_module_config_from_db(module_id, workflow_version_id)
        step_config = response.get('config')
        config_string = response.get('config_string')
        platformModuleId = response.get('platformModuleId')
        #config_loc = utils.generate_temp_config(platformModuleId, config_string)
        return StepFactory().getStepImplementation(context, platformModuleId, step_config, config_string)
​
​
def airflow_step(workflow_version_id, definition, context):
​
    module_id = definition.get("id")
    # config_loc =  definition.get("ConfigLocation")
    if definition.get("id") is not None:
        response = fetch_module_config_from_db(module_id, workflow_version_id)
        step_config = response.get('config')
        config_string = response.get('config_string')
        platformModuleId = response.get('platformModuleId')
        #config_loc = utils.generate_temp_config(platformModuleId, config_string)
        return AirflowFactory().getStepImplementation(context, platformModuleId, step_config, config_string)
​
"""
This is the heart of the workflow engine. The pseudo code is as follows:
Step 1: For each Module in the Workflow Config:
    Fetch the Module Config yaml from DDB
    Create Deployment Artifacts required for the workflow.
    Build Step by using StepFactory class.
Step 2: Chain the Modules based on the Workflow Config "Step" Definition.
Step 3: Return the work flow definition.
"""
​
def build_workflow(workflow_version_id, is_dry_run):
​
    # This is a request context object to store the context of the current workflow.
    # TODO: Fetch default  context details from the workflow config.
    context = {
        'pipeline_execution': {
            'BaseLocation': constants.S3_BASE_LOCATION,
            'sagemaker_session': Session(),
            'NotificationArn': constants.NOTIFICATION_TOPIC
        },
        'step_execution': {}
    }
    # Fetches the config yaml from DB
    config_yaml = fetch_config_from_db(workflow_version_id, constants.WORKFLOW_CONFIG_VERSION)
    deployment_steps = {}
    # List of Modules Referred in the Workflow Definition.
    modules = config_yaml.get('modules')
    steps_list = []
    #  If not Dry Run - Fetch the Deployment Config Add CFT Resource Creation Steps.
    if not is_dry_run:
        deployment_yaml = fetch_deployment_config(workflow_version_id) 
        #Gets deployment details, name and type from module yaml for each module
​
        deployment_steps = create_deployment_steps(deployment_yaml)
        # Create, Wait,  Get Status and Delete are Resource Creation Steps.
        steps_list.append(deployment_steps['create'])
        steps_list.append(deployment_steps['wait'])
        steps_list.append(deployment_steps['get_status'])
        context['step_execution']['resource_names'] = deployment_steps['get_status']
​
​
    for step_name, step_definition in modules.items():
        if type(step_definition) is not str and constants.ORCHESTRATION_ENGINE == 'Airflow':
            step = airflow_step(workflow_version_id, step_definition, context)
            context['step_execution'][step_name] = step
        else:
            step = build_step(workflow_version_id, step_definition, context)
            context['step_execution'][step_name] = step
​
    # Now that the modules are defined, iterate through the steps and assemble them.
    steps = utils.ordered_config(config_yaml.get('steps'))
​
    for step in steps:
        steps_list.append(context['step_execution'][step])
​
    # If not a Dry Run, then clean up the resources. In case of a dry run no resources are created anyways!
​
    if not is_dry_run:
        steps_list.insert(len(steps_list) , deployment_steps['delete'])
        # Return a Data Science SDK Workflow object.
        workflow_name = config_yaml.get('metaData')['name'].replace(" ","")
​
    #removing None instances from steps_list
    modified_steps_list = [i for i in steps_list if i]
​
    return Workflow(
        name=workflow_name + "-" + str(uuid.uuid1()),
        definition=Chain(modified_steps_list),
        role=constants.WORKFLOW_EXEC_ROLE
    )
​
'''
This method is no-longer used in the UI.
The idea of this method is to see if the pipeline created in the UI has any syntax error or not.
This method - takes in the workflow config id and tries to build a pipeline by using step function api.
It will not execute / create a pipeline. It will only be used to build a pipeline.
If the above is successful, then method stores the definition and the flow chart diagram generated in the DDB.
'''
​
def dry_run_create_pipeline(workflow_version_id):
​
    pipeline = build_workflow(workflow_version_id, False)
​
    if pipeline is None:
        return "Uh oh.. Looks like the Pipeline has some errors", 400
​
    pipeline.create()
    definition = pipeline.definition
    template = pipeline.get_cloudformation_template()
    html = '<script type="text/javascript" src="/static/require.js"></script>' + pipeline.render_graph().data
    utils.save_workflow_definition(workflow_version_id, definition, template, html)
    return template, 201
​
'''
This API is to visualize a Workflow Version in a SVG format. This is not used in the UI.
Suggestion is to use this API in the UI for debugging and visualization purposes.
'''
@app.route('/workflow/<workflow_version_id>/definition', endpoint="view_pipeline", methods=['GET'])
​
def view_pipeline(workflow_version_id):
    return utils.fetch_workflow_svg(workflow_version_id), 200
​
'''
Method takes in Workflow Config ID, builds step function definition and executes the same.
'''
​
def execute(workflow_version_id):
​
    workflow_execution_id = utils.check_and_update_execution_status(workflow_version_id)
    # workflow_execution_id = str(uuid.uuid4())[:8]
    if workflow_execution_id is None:
        return "Uh oh.. Looks like there is already a workflow under execution..Please try after sometime!", 400
​
    pipeline = build_workflow(workflow_version_id, False)
​
    # Data Science SDK that creates a pipeline and execute it.
    # Create will only create step function defintion.
    # Execution will result in actual state machine to be created.
    updated_definition = pipeline.definition.to_json().replace("TransformJobName","TransformJobName.$")
    print(updated_definition)
​
    if constants.ORCHESTRATION_ENGINE == 'Airflow':
        output_dir = '/workflowengineService/yamls/'+str(workflow_execution_id)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        with open (output_dir+'/definition.yaml', 'w') as file:
            documents = yaml.dump(updated_definition, file)
        s3_client = boto3.client('s3')
        response = s3_client.upload_file(output_dir+'/definition.yaml', BUCKET_NAME, str(workflow_execution_id)+"/definition.yaml")
        airflow_dag = dag(workflow_execution_id)
​
    else:
        modified_pipeline = Workflow(
            name= pipeline.name,    
            definition =FrozenGraph.from_json(updated_definition),
            role=constants.WORKFLOW_EXEC_ROLE
            )
        modified_pipeline.create()
        modified_pipeline_flow = modified_pipeline.execute()
        template = modified_pipeline.get_cloudformation_template()
        html = '<script type="text/javascript" src="require.js"></script>' + modified_pipeline_flow.render_progress().data
      #Saving the Execution ARN, Resulting HTML Progress in the DDB
        utils.save_execution_results_in_db(workflow_execution_id, html, modified_pipeline_flow.execution_arn, template)
        return {"message": "Workflow Execution Created",
                "execution_id": workflow_execution_id}
​
​
'''
This method is used for visualizing a workflow execution status.
It takes in Workflow Execution ID as input.
Queries the DDB to get the the details [execution arn and asl] of the execution.
Uses the Data Science SDK to render the execution details as a SVG.
Data Science SDK method - list_events() - will generate teh list of all the events that were executed as a HTML
Data Science SDK method - render_progress() - will generate a SVG of the state machine.
'''
​
@app.route('/workflow/<workflow_version_id>/execution/<workflow_execution_id>/status', endpoint="view_execution_status",
​
           methods=['GET'])
​
def view_execution_status(workflow_version_id, workflow_execution_id):
    client = boto3.client('stepfunctions')
​
    # Get Execution ARN from DDB, Return 404 if not found
    execution_arn = utils.get_execution_arn(workflow_version_id, workflow_execution_id)
​
    if execution_arn is None:
        return "Uh oh.. Looks like there is no execution trace..", 404
​
    # Get the details of the state machine from Boto3.
​
    state_machine_details = client.describe_execution(
        executionArn=execution_arn
    )
​
    workflow_execution_details = client.describe_state_machine(stateMachineArn=state_machine_details['stateMachineArn'])
​
    # Re-create a Workflow object and teh Execution object from the Step Function Execution details.
    workflow = Workflow(
        name=workflow_execution_details['name'],
        definition=FrozenGraph.from_json(workflow_execution_details['definition']),
        role=workflow_execution_details['roleArn'],
        state_machine_arn=workflow_execution_details['stateMachineArn'],
        client=client
    )
​
    execution = Execution(
        workflow=workflow,
        execution_arn=state_machine_details['executionArn'],
        start_date=state_machine_details['startDate'],
        status=state_machine_details['status'],
        client=client
    )
    # require.js is added to render the svg graphics. Its a workaround done to display the output of render_progress
    # in a browser.
​
    return '<script type="text/javascript" src="/static/require.js"></script>' + execution.list_events(html=True).data + execution.render_progress().data, 200
​
'''
This method is used to publish the CFT created to the Service Catalog API.
It takes in workflow config id as the input, builds workflow and then publishes the generated CFT to Service Catalog.
'''
​
def publish(workflow_version_id):
​
    pipeline = build_workflow(workflow_version_id, False)
    template = pipeline.get_cloudformation_template()
    # template = template.replace("TransformJobName", "TransformJobName.$")
    # template = template.replace("S3Uri""", "S3Uri.$")
    response = utils.publish(template.replace("TransformJobName", "TransformJobName.$"), workflow_version_id)
    return response
​
'''
This is the entry point for workflow engine.
The input request looks like this:
    POST /workflow/1234567 HTTP/1.1
    Host: localhost:8080
    Content-Type: application/json
    {
    "action": "execute|dry-run|publish"
    }
​
    Based on the action - the appropriate internal methods will be called.
    It returns a success / throws error in case of failure.
'''
​
@app.route('/workflow/<workflow_version_id>', endpoint="process_request",
           methods=['POST'])
​
def process(workflow_version_id):
​
    request_data = request.json
    action = request_data.get('action')
    response = None
    try:
        if action == 'dry-run':
            response = dry_run_create_pipeline(workflow_version_id)
        elif action == 'publish':
            response = publish(workflow_version_id)
        elif action == 'execute':
            response = execute(workflow_version_id)
    except Exception as e:
        print("Error while processing", e.with_traceback())
        return {"message": "error", "response_details": response}, 201
​
    if response is not None:
        return {"message": "accepted", "response_details": response}, 201
    else:
        return {"message": "error", "response_details": response}, 500
​
if __name__ == "__main__":
    #init() #Commmented because not needed in actual deployment
    app.run(host="0.0.0.0", port=8080)
    # print(publish('1598592300'))