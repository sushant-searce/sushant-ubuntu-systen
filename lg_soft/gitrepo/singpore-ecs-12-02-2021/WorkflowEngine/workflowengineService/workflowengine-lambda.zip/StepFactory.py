import punq

from implementations.ChoiceStep import ChoiceStepBuilder
from implementations.ECSStep import ECSStepBuilder
from implementations.LambdaStep import LambdaStepBuilder
from implementations.NotificationStep import NotificationStepBuilder
from implementations.ParallelStep import ParallelStepBuilder
from implementations.SageMakerStep import InferenceStepBuilder
from implementations.LGECSStep import LGECSStepBuilder
from implementations.ECSEC2Step import ECSEC2StepBuilder

"""

punq is a simple DI library.  Th idea is create all the module implementations and store it in
a registry. Then inside the engine, other components can make use of this registry.

For eg:
container.register("lambda",LambdaImplementation)
container.resolve("lambda") -->  will return lambda implementation

"""

container = punq.Container()


class StepFactory:
    """
    In the init, adding the step builders to a container.
    """


    def __init__(self):
        container.register("function", LambdaStepBuilder)
        container.register("batch_inference", InferenceStepBuilder)
        container.register("notify_email", NotificationStepBuilder)
        container.register("choice", ChoiceStepBuilder)
        container.register("ecs", ECSStepBuilder)
        container.register("parallel", ParallelStepBuilder)
        container.register("fargate", LGECSStepBuilder)
        container.register("EC2", ECSEC2StepBuilder)

    @staticmethod
    def getStepImplementation(context, module_id, definition, config_file_location):
        try:
            step = container.resolve(definition.get('deployment').get('type')).getStep(context, module_id, definition, config_file_location)
            if step is not None:
                return step
        except Exception as e:
            print("Un-supported Operation",e)
            raise
