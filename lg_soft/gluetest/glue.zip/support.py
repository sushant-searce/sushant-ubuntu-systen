from test import testing

def support_testing():
    testing()
    print("the second test is successful")