def testing():
    print("the first test is succesfull")